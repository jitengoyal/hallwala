HallWala README
==================

Getting Started
---------------

- cd <directory containing this file>

- $VENV/bin/python setup.py develop

- $VENV/bin/initialize_HallWala_db development.ini

- $VENV/bin/pserve development.ini


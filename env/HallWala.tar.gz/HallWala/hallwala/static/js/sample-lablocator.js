var mapObject,markerList=[],directionsDisplay,pOptions,jsSearchData,locations = {},sortedLocations = {},newLocations = {},lat,lng,$directionsNav=$("#directions-nav");
function adjustSearchResultsHeight(){
	$("#hme-content .search-results").height(($(window).height()-$("#header-grad-bg").outerHeight()-$("footer").outerHeight()-24-$("#map-tabs-content #hme-content .featured").outerHeight()));
	$("#directions-nav .search-results").height(($(window).height()-$("#header-grad-bg").outerHeight()-$("footer").outerHeight()-24-$("#map-tabs-content #directions-nav .featured").outerHeight()));
}
function initializeCustomScrollbar($tempList){
	adjustSearchResultsHeight();
	if(!$tempList.hasClass("mCustomScrollbar")){
		$tempList.mCustomScrollbar({
			advanced:{
		        updateOnContentResize: true,
		        updateOnBrowserResize: true
		    }
		});
	}
	else{
		$tempList.mCustomScrollbar("destroy");
		$tempList.mCustomScrollbar({
			advanced:{
		        updateOnContentResize: true,
		        updateOnBrowserResize: true
		    }
		});
	}
}
function HomeControl(controlDiv, map) {
 google.maps.event.addDomListener(zoomout, 'click', function() {
   var currentZoomLevel = mapObject.getZoom();
   if(currentZoomLevel != 0){
     mapObject.setZoom(currentZoomLevel - 1);}

  });

   google.maps.event.addDomListener(zoomin, 'click', function() {
   var currentZoomLevel = mapObject.getZoom();
   if(currentZoomLevel != 21){
     mapObject.setZoom(currentZoomLevel + 1);}

  });
}
function directionsInfoEvent($targetElement){
	$("#hme-content").hide();
	$directionsNav.find("#directions-panel").html("");
	$directionsNav.show();
	$("#direction_a,#direction_b").val("");
	$("#direction_b").val($targetElement.parents(".infoBox-content").find(".address").text());
	adjustSearchResultsHeight();
}
function initializeDirectionTabs(){
	$("#directions-close").click(function(e) {
        e.preventDefault();
		$("#hme-content").show();
		$directionsNav.hide();
		populateLocations(jsData,lat,lng);
		initializeCustomScrollbar($("#hme-content .search-results"));
    });
	$("#direction-options a.direction-option").click(function(event){
		event.preventDefault();
		$("#direction-options a.direction-option").removeClass("active");
		$(this).addClass("active");
		$("#direction_hme_form").trigger("submit");
	});
	$("#switch-from-to").click(function(e) {
        e.preventDefault();
		var temp;
		temp=$("#direction_a").val();
		$("#direction_a").val($("#direction_b").val());
		$("#direction_b").val(temp);
		$("#direction_hme_form").trigger("submit");
    });
}
function initializeDirectionAccordian($directionList,directionResult,routesArray){
	var infocontent,paddingVal="";
	if(directionsDisplay) {
		directionsDisplay.setMap(null);directionsDisplay = null;
	}
	if(pOptions) {
		for (var i=0; i<pOptions.length; i++){
			pOptions[i].setMap(null);
	       }
		pOptions=null;
	}
}
function makeMarker( position, icon, title,infoWindowContent ) {
var markernew=null;
markernew = new google.maps.Marker({
  position: position,
  map: mapObject,
  icon: icon,
  title: title
 });
var infocontent="<div class=\"infoBox-arrow\"></div><div class=\"infoBox-content direction-info\">"+infoWindowContent+"</div></div>";
var infowindowdata = {
		content: infocontent,
		disableAutoPan: false,
		maxWidth: 0,
		pixelOffset: new google.maps.Size(15,-47),
		zIndex: null,
		boxStyle: {
			background: "url('/resmed-html/content/src/main/content/jcr_root/etc/designs/resmeddmp/images/map-pin-arrow.png') no-repeat 0 22px",
			opacity: 2,
			width: "230px"
		},
		closeBoxMargin: "5px 5px 2px 2px",
		closeBoxURL: "/resmed-html/content/src/main/content/jcr_root/etc/designs/resmeddmp/images/map-pin-close.png')",
		infoBoxClearance: new google.maps.Size(1, 1),
		isHidden: false,
		pane: "floatPane",
		enableEventPropagation: true
	};
	var ibnew = new InfoBox(infowindowdata);
	markerList.push(markernew);
	google.maps.event.addListener(markernew, 'click', (function(markernew, infowindowdata) {
		return function() {
			 $('.infoBox').hide();
			ibnew.setOptions(infowindowdata);
			ibnew.open(mapObject, markernew);
		}
	})(markernew, infowindowdata));
markernew=null;
}
function checkForADPChange($directionList){
	var myVar = setTimeout(function(){
		if($directionList.find("img").length>0){
			$directionList.find("img").each(function(index,value){
				if (index%2 == 0) {
					$(this).replaceWith("<img src='/resmed-html/content/src/main/content/jcr_root/etc/designs/resmeddmp/images/map-pin-a.png'>");
				}
			    else {$(this).replaceWith("<img src='/resmed-html/content/src/main/content/jcr_root/etc/designs/resmeddmp/images/map-pin-b.png'>");}
			});
			$("#adp-placemark img, .adp-placemark img").css("visibility","visible");
			clearTimeout(myVar);
		}
		else{
			checkForADPChange($directionList);
		}
	},1000);
}
function showSteps(directionResult,fromDir,toDir) {
	var myRoute = null,myRouteSummary=null,i=0,markerid=null,routeString="",$directionList=$("#directions-nav #directions-panel"),routesArray=[];
	$directionList.html("");
	var infocontent,paddingVal="";
	if(directionsDisplay) {
		directionsDisplay.setMap(null);directionsDisplay = null;
	}
	if(pOptions) {
		for (var i=0; i<pOptions.length; i++){
			pOptions[i].setMap(null);
	       }
		pOptions=null;
	}
	$(markerList).each(function () {
		 this.setMap(null);
	});
	markerList = [];
	$('.infoBox').hide();
	var icons = {
	  start: new google.maps.MarkerImage(
	   // URL
	   '/resmed-html/content/src/main/content/jcr_root/etc/designs/resmeddmp/images/map-pin-a.png',
	   // (width,height)
	   new google.maps.Size( 25, 30 ),
	   // The origin point (x,y)
	   new google.maps.Point( 0, 0 ),
	   // The anchor point (x,y)
	   new google.maps.Point( 12, 30 )
	  ),
	  end: new google.maps.MarkerImage(
	   // URL
	   '/resmed-html/content/src/main/content/jcr_root/etc/designs/resmeddmp/images/map-pin-b.png',
	   // (width,height)
	   new google.maps.Size( 25, 30 ),
	   // The origin point (x,y)
	   new google.maps.Point( 0, 0 ),
	   // The anchor point (x,y)
	   new google.maps.Point( 12, 30 )
	  )
	 };
	directionsDisplay=new google.maps.DirectionsRenderer({
		polylineOptions: {
		  strokeColor: "#000",
		  strokeWeight: 5,
		  strokeOpacity: 0.7
		},suppressMarkers: true
	});
	directionsDisplay.setMap(mapObject);
	directionsDisplay.setPanel(document.getElementById('directions-panel'));
	directionsDisplay.setDirections(directionResult);
	var leg = directionResult.routes[ 0 ].legs[ 0 ];
	makeMarker( leg.start_location, icons.start, fromDir,fromDir );
	makeMarker( leg.end_location, icons.end, toDir,toDir );
	initializeCustomScrollbar($("#directions-nav .search-results"));
	checkForADPChange($directionList);
	google.maps.event.addListener(directionsDisplay, 'routeindex_changed', function() {
		$("#adp-placemark img, .adp-placemark img").css("visibility","hidden");
			checkForADPChange($directionList);
    });
}
function getDirectionsValues(){
	$("#direction_hme_form").submit(function(event){
		event.preventDefault();
		$("#direction_a,#direction_b").blur();
		$(this).find("button[type=submit]").focus();
		$("#directions-nav #directions-panel").html("");
		var fromDir=$.trim(''+$("#direction_a").val()),toDir=$.trim(''+$("#direction_b").val());
		if(fromDir && ($.trim(''+fromDir)).length>0 && toDir && ($.trim(''+toDir)).length>0){
			var selectedMode=$("a.direction-option.active").data("travelmode");
			if(selectedMode && ($.trim(''+selectedMode)).length>0){}
			else{
				selectedMode="DRIVING";
			}
			var directionsService = new google.maps.DirectionsService();
			var directionsRequest = {
			  origin: fromDir,
			  destination: toDir,
			  provideRouteAlternatives: true,
			  travelMode: google.maps.TravelMode[selectedMode],
			  unitSystem: google.maps.UnitSystem.IMPERIAL
			};
			directionsService.route(
			  directionsRequest,
			  function(response, status)
			  {
				if (status == google.maps.DirectionsStatus.OK)
				{
					showSteps(response,fromDir,toDir);
				}
				else
				  $("#error").append("Unable to retrieve your route<br />");
			  }
			);
		}
		return false;
	});
}
/* Finding distance between two co-ordinates */
function calculateDistance(lat1, lon1, lat2, lon2, unit) {
    var radlat1 = (Math.PI * lat1/180),radlat2 = (Math.PI * lat2/180),radlon1 = (Math.PI * lon1/180),radlon2 = (Math.PI * lon2/180),theta = lon1-lon2,radtheta = (Math.PI * theta/180),dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
    dist = Math.acos(dist);
    dist = dist * 180/Math.PI;
    dist = dist * 60 * 1.1515;
    if (unit=="km") { dist = dist * 1.609344 };
    return dist;
}
// Set distance limit as 20
sortByDistance = function(obj, type) {
  var temp_array = [];
  for (var key in obj) {
	  
    if (obj.hasOwnProperty(key)) {
	   if (key<50) {
       temp_array.push(key);
      }
   }
  }
  temp_array.sort(function(a,b) { return parseFloat(a)-parseFloat(b); });

  var temp_obj = {};
  for (var i=0; i<temp_array.length; i++) {
    temp_obj[temp_array[i]] = obj[temp_array[i]];
  }
  return temp_obj;
};
function getRoundedFigure(i) {
    return Math.round(i * 100) / 100;
}
function isEmpty(obj) {
    for(var key in obj) {
        if(obj.hasOwnProperty(key))
            return false;
    }
    return true;
}
function isArray(obj) {
    return Object.prototype.toString.call(obj) === '[object Array]';
}
function populateLocations(jsData,lat, lng){
	
	var latlngbounds = new google.maps.LatLngBounds(null) , myloc = null,listContent="",$locatorList=$("#search-results-list"),withTestChecked = $('#with_tests .icon-parent .icon-child').css('display') == 'none' ? 'no' :'yes',withoutTestChecked = $('#without_tests .icon-parent .icon-child').css('display') == 'none' ? 'no' :'yes',count = 0,$distanceUnit,$locatorMobileList=$("#mobile-search-results-list");
	$locatorList.html("");
	$locatorMobileList.html("");
	newLocations = {};
	if($('#labLocatorDistanceType')){
		$distanceUnit = $('#labLocatorDistanceType').val();
		if ($distanceUnit.length ==0 && $distanceUnit =='') {
			$distanceUnit = "mi";
		}
	}
	else $distanceUnit="mi";
	$.each(jsData, function (i, myloc) {
		$.each(myloc, function (i1, location) {
			if (location.status == "active") {
				var dis = calculateDistance(lat,lng,location.address.latitude,location.address.longitude,$distanceUnit);	
				var services = location.services.service,					
				isWithTest = services[1] != undefined && typeof services[1] !='undefined' && services[1] != 'undefined' && services[1] == 'distributor' ? true : false,
				isWithOutTest = services[0] != undefined && typeof services[0] !='undefined' && services[0] != 'undefined' && services[0] == 'sleep lab' ? true : false;
				
				if(withTestChecked =='yes') {
					if(isArray(services)) {
						for (var i = 0; i < services.length; i++) {
							if(services[i] === "sleep lab") {
								 newLocations[dis] = [location];
							}
						} 
					} else if (services === "sleep lab"){
						 newLocations[dis] = [location];
					}
				}
				
				if(withoutTestChecked =='yes') {
					if(isArray(services)) {
						for (var i = 0; i < services.length; i++) {
							if(services[i] === "distributor") {
								 newLocations[dis] = [location];
							}
						} 
					} else if (services === "distributor"){
						 newLocations[dis] = [location];
					}
				}
			}
		});
	});
	sortedLocations = sortByDistance(newLocations);
	
	$(markerList).each(function () {
		 this.setMap(null);
	});
	markerList = [];
	$('.infoBox').hide();
	if(directionsDisplay) {
		directionsDisplay.setMap(null);directionsDisplay = null;
	}
	if(pOptions) {
		for (var i=0; i<pOptions.length; i++){
			pOptions[i].setMap(null);
		   }
		pOptions=null;
	}
	mapObject.setMapTypeId(google.maps.MapTypeId.ROADMAP);
	$.each(sortedLocations, function (i, myloc) {
		$.each(myloc, function (i1, location) {
			var cont = location,weburl="";
	        lat = parseFloat(cont.address.latitude);
	        lng = parseFloat(cont.address.longitude);
	        location = new google.maps.LatLng(lat, lng);
	        latlngbounds.extend(location);
	        var infocontent = "";
	     // Google Map InfoWindow
	        var city = "";
	        if(!isEmpty(city)) {
	        	city = cont.address.city;
	        }
	        listContent="<li>";
	        listContent+="<div class=\"search-result\" id=\"route_marker_"+count+"\" data-markerid=" + count + " data-longitude=\""+lng+"\" data-latitude=\""+lat+"\">";
	        listContent+="<div class=\"result-number\"><img src=\"/resmed-html/content/src/main/content/jcr_root/etc/designs/resmeddmp/images/map-pins/map-pin-"+(++count)+".png\">"+"</div>";
	        listContent+="<div class=\"result-title\">"+cont.site_name+"</div>";
	        listContent+="<div class=\"result-distance\">"+getRoundedFigure(i)+$distanceUnit+"</div>";
	        listContent+="<div class=\"result-info\">";
	        listContent+="<p class=\"address\">"+cont.address.street+"<br/>"+city+" "+cont.address.state+" "+cont.address.postal+"</p>";
			if(cont.website != undefined && cont.website != 'undefined') {
				weburl=cont.website;
				if(weburl.length>25){
					weburl=weburl.substr(0,25);
					weburl+="...";
				}
				listContent+="<a href=\""+cont.website+"\" title=\""+cont.website+"\" target=\"_blank\" class=\"website\">"+weburl+"</a><br/>";
			}
			if($("html").hasClass("lt-ie9")){
				if((cont.phone).length>0){
					listContent+="<p class=\"telephone\">Tel:";
			        listContent+=cont.phone+"</p>";
				}
			}
			else{
				if(!isEmpty(cont.phone)) {
			        listContent+="<p class=\"telephone\">Tel:";
			        listContent+="<a href='tel:"+cont.phone+"'>"+cont.phone+"</a></p>";
				}
			}
	        listContent+="</div></div></li>";
	        
	        $locatorList.append(listContent);
	        $locatorMobileList.append(listContent);
			
	        infocontent+="<div class=\"infoBox-arrow\"></div><div class=\"infoBox-content\"><p class=\"title\">"+cont.site_name+"</p>";
	        infocontent+="<p class=\"address\">"+cont.address.street+", <br/>"+city+", "+cont.address.state+", <br/>"+cont.address.postal+"</p>";
	        infocontent+="<a href=\"#\" onclick=\"javascript:directionsInfoEvent($(this))\" class=\"cta-link primary\">Get Directions<span aria-hidden=\"true\" class=\"icon-parent icon-circle-1p0\"><span class=\"icon-child icon-arrow-dotted-right\"></span></span></a></div>";
	        // onclick=\"initializeDirectionTabs($(this))\"
	        var infowindowid = {
	            content: infocontent,
	            disableAutoPan: false,
	            maxWidth: 0,
	            pixelOffset: new google.maps.Size(15,-47),
	            zIndex: null,
	            boxStyle: {
	            	background: "url('/resmed-html/content/src/main/content/jcr_root/etc/designs/resmeddmp/images/map-pin-arrow.png') no-repeat 0 22px",
	                opacity: 2,
	                width: "230px"
	            },
	            closeBoxMargin: "5px 5px 2px 2px",
	            closeBoxURL: "/resmed-html/content/src/main/content/jcr_root/etc/designs/resmeddmp/images/map-pin-close.png')",
	            infoBoxClearance: new google.maps.Size(1, 1),
	            isHidden: false,
	            pane: "floatPane",
	            enableEventPropagation: true
	        };

	        var ib = new InfoBox(infowindowid);
	     // Setting up the Marker
	        var markerid = new google.maps.Marker({
	            position: location,
	            map: mapObject,
	            icon: "/resmed-html/content/src/main/content/jcr_root/etc/designs/resmeddmp/images/map-pins/map-pin-"+(count)+".png",
	            animation: google.maps.Animation.DROP,
				id:"marker_"+(count-1)
	        });
			$locatorList.find('li div.search-result a').click(function(e) {
                e.stopPropagation();
            });
			$locatorMobileList.on("click","li div.search-result a",function(e) {
                e.stopPropagation();
            });
	        markerList.push(markerid);
	        // Binding the Click event for all the markers
	        google.maps.event.addListener(markerid, 'click', function () {
	            $('.infoBox').hide(); //Reset & Hide the infobox 
	            ib.open(mapObject, this);
				$locatorList.find('li div.search-result').removeClass("active");
	        	$("#route_"+this.id).addClass("active");
	        });
	        mapObject.fitBounds(latlngbounds);
			google.maps.event.addDomListener(window, "resize", function() {
				$("#map_canvas").height($(window).height()-$("#header-container").outerHeight()-$("footer").outerHeight());
				$("#map_container").css("padding-top",$("#header-container").outerHeight());
				adjustSearchResultsHeight();
				if($locatorList.css("display")=="none"){
					 var center = mapObject.getCenter();
					 google.maps.event.trigger(mapObject, "resize");
					 mapObject.setCenter(center); 
				}
				else{
					google.maps.event.trigger(mapObject, "resize");
					mapObject.fitBounds(latlngbounds);
				}
			});
		});
	});
	if($("#map_static_view").css("display")=="block"){
		$('html,body').animate({scrollTop: $("#map_static_view").offset().top}, 1500, 'easeInOutQuint',function(){});
	}
	if(count == 0){
		mapObject.setZoom(8);
		mapObject.setCenter(new google.maps.LatLng(lat,lng));
	}
	$locatorList.find('li div.search-result').each(function(index, element) {
        $(this).click(function (event) {
			event.preventDefault();
			$('.infoBox').hide(); //Reset & Hide the infobox 
			var j = $(this).attr('data-markerid');
			google.maps.event.trigger(markerList[j], "click");
			//$locatorMobileList.find('li div.search-result').eq(index)
		});
    });
	$locatorMobileList.on("click",'li div.search-result',function(event) {
			event.preventDefault();
			var resultDirections=$(this).find(".address").text(),$clonedItem;
			$locatorMobileList.find('li div.search-result').removeClass("active");
			$(this).addClass("active");
			$clonedItem=$(this).parents("li").clone();
			var markers = "",lat= $(this).data("latitude"),longitude= $(this).data("longitude"),directions = $(this).data("directions");
			markers=markers+"&markers=icon:"+$(this).find(".result-number img").attr("src")+"|"+lat+","+longitude;
			var mapURL="//maps.google.com/maps/api/staticmap?center="+lat+","+parseFloat(longitude)+markers+"&zoom=14&size=600x360&maptype=roadmap&sensor=false", mapDirectionsURL="//maps.google.com/maps?saddr=&daddr="+resultDirections+"";
			$("#map_static_view").attr("src",mapURL);
			$("#map_static_directions_container").show();
			$(this).parents("li").remove();
			$locatorMobileList.prepend( $clonedItem );
			$("#map_static_view_directions").attr("href",mapDirectionsURL);
			$('html,body').animate({scrollTop: $("#map_static_view").offset().top}, 1500, 'easeInOutQuint',function(){});
    });
	$locatorMobileList.find('li div.search-result').eq(0).trigger("click");
	initializeDirectionTabs();
	getDirectionsValues();
}
function initialize() {
	if($('#map_canvas').length <= 0){return;}
    //Setting default Map attributes
    var mapOptions = {
    	mapTypeControl: false,
        center: new google.maps.LatLng(42.032974,-15.468750),
		zoom: 2,
		mapTypeId: google.maps.MapTypeId.ROADMAP,
        panControl: false,
        zoomControl:false,
        streetViewControl: false
    };
	
    // Including GoogleMap in the DOM Element
	if(mapObject){
		//mapObject.setMapTypeId(google.maps.MapTypeId.ROADMAP);
	}	
	else{
		mapObject = new google.maps.Map(document.getElementById("map_canvas"),mapOptions);
		// Create the DIV to hold the control and
		// call the HomeControl() constructor passing
		// in this DIV.
		var homeControlDiv = document.createElement('div');
		var homeControl = new HomeControl(homeControlDiv, mapObject);
	
		homeControlDiv.index = 1;
		mapObject.controls[google.maps.ControlPosition.TOP_LEFT].push(homeControlDiv);
			
		$("#map_static_view").attr("src","//maps.google.com/maps/api/staticmap?center=0,0&zoom=1&size=600x360&maptype=roadmap&sensor=false");
	}
    $("#custom-zoom").animate({right: "12px",opacity:"1"}, 800);
	$("#maps-tabs-wrapper").animate({left: "12px",opacity:"1"}, 800);
}
function initHMELocation(criteria,lat,lng,jsonUrl){
	////////////////Please keep this code as is till the site goes finally in UAT.
	var response = sampleJson.map,
	jsSearchData=sampleJson.map;
    jsData = sampleJson.map;
	populateLocations(response,lat, lng);
	$('.custom-map-checkbox').click(function(e){			
		e.preventDefault();
		populateLocations(response,lat, lng);
	});
	////////////Test Sample Data End Above lines should remove while inegraion//////
	/*var jqxhr = $.get( jsonUrl+'?address='+criteria, function(data) {
    		jsData = data.map;
            cacheData = jsData;
			jsSearchData=jsData;
            //populateLocations(jsData);
        	populateLocations(jsData,lat, lng);
		}).done(function() {
		    
		}).fail(function(xhr, ajaxOptions, thrownError) {
		    //alert( thrownError );
		});
	*/
};
function searchHMELocation(){
	var $address = $('#search_hme'),
		$withTest = $('#with_tests .icon-parent .icon-child'),
		$withoutTest = $('#without_tests .icon-parent .icon-child'),
		jsonUrl = $address.data('map-json-url');	
	if ($address.length && $address.val()!='') {
		
		var val = $address.val(),
			geocoder = new google.maps.Geocoder();
		geocoder.geocode( {'address': val}, function(results, status) {
		  if (status == google.maps.GeocoderStatus.OK) {
		  	
			lat = results[0].geometry.location.lat();
			lng = results[0].geometry.location.lng();		
			var criteria = {};
			criteria.address = val;
			criteria.lat = lat;
			criteria.lng = lng;
			criteria.withTest =  $withTest.css('display') == 'none' ? 'no' :'yes';
			criteria.withoutTest =  $withoutTest.css('display') == 'none' ? 'no' :'yes';
			
			// Added these lines for IE7 support since JSON.stringify is not working.
			if($("html").hasClass("lt-ie8")){
				var len = $.map(criteria, function(n, i) { return i; }).length,jd = '{',count=0;
				for (var k in criteria) {
					count++;jd=(count!==len)?jd+"'"+k+"':'"+criteria[k]+"',":jd+"'"+k+"':'"+criteria[k]+"'";
				}
				jd = jd+"}";
				criteria = jd;
			}
			else criteria = JSON.stringify(criteria);
			
		  	initHMELocation(criteria, lat, lng,jsonUrl);
		  }
		});
	}
}
$(document).ready(function(e) {
	$("#megamenu-container,#search_megamenu").addClass("maps-megamenu");
	$('#with_tests .icon-parent .icon-child').css({'display':'inline'});
	$("#search_hme_form").submit(function(event){    	
    	event.preventDefault();
    	$("#search_hme").blur();
    	$("#with_tests").focus();
    	searchHMELocation();
    });
	$("#search_hme_form a.custom-map-checkbox").each(function(index, element) {
        $(this).click(function(event){
			event.preventDefault();
			$(this).find(".icon-child").toggle();
			$("#search_hme_form").trigger("submit");
		});
    });
    $("#map_canvas").height($(window).height()-$("#header-grad-bg").outerHeight()-$("footer").outerHeight());
	$("#map_container").css("padding-top",$("#header-grad-bg").outerHeight());
	google.maps.event.addDomListener(window, 'load', initialize);
	adjustSearchResultsHeight();
	initializeCustomScrollbar($("#hme-content .search-results"));
});
var sampleJson = {
		"map": {
			"location": [
				{
					"hall_id": "1",
					"hall_name": "Pizza Hut 1",
					"hall_address": {
						"country": "India",
						"address_1": "Shop No.6-3-1090/B/4, The Grand Towers",
						"address_2": "Lumbini Classic Apartment, Raj Bhavan Road",
						"locality":"Somajiguda",
						"city": "Hyderabad",
						"state": "Andhra Pradesh",
						"postal": "500082",
						"latitude": "17.252276",
						"longitude": "78.274423"
					},
					"hall_rating":"5",
					"hall_website": "http://www.cityhospital.org",
					"hall_phone": "8142263464",
					"hall_type": {
						"corporate": "true",
						"wedding": "true",
						"party": "true",
						"banquet":"true"
					},
					"hall_features":["icons-parking;Parking","icons-coffee;Cafe","icons-bar;Bar","icons-book;Reading hall","icons-swimming;Swimming pool","icons-signal;Wi-fi","icons-gym;Gym","icons-taxi;Transport","icons-parking;Parking","icons-coffee;Cafe","icons-bar;Bar","icons-book;Reading hall","icons-swimming;Swimming pool","icons-signal;Wi-fi","icons-gym;Gym","icons-taxi;Transport"]
				},
				{
					"hall_id": "2",
					"hall_name": "Pizza Hut 2",
					"hall_address": {
						"country": "India",
						"address_1": "8-2-630 to 636, Rmk Plaza Road",
						"address_2": "Road Number 12",
						"locality":"Banjara Hills",
						"city": "Hyderabad",
						"state": "Andhra Pradesh",
						"postal": "500034",
						"latitude": "17.242956",
						"longitude": "78.270041"
					},
					"hall_rating":"4",
					"hall_website": "http://www.cityhospital.org",
					"hall_phone": "040 6666 0255",
					"hall_type": {
						"corporate": "true",
						"wedding": "false",
						"party": "false",
						"banquet":"false"
					},
					"hall_features":["icons-parking;Parking","icons-coffee;Cafe","icons-bar;Bar","icons-book;Reading hall","icons-swimming;Swimming pool","icons-signal;Wi-fi","icons-gym;Gym"]
				},
				{
					"hall_id": "3",
					"hall_name": "Pizza Hut 3",
					"hall_address": {
						"country": "India",
						"address_1": "No 6-3-1098/B/4, Ground Floor",
						"address_2": "The Grand Building, Raj Bhavan Road",
						"locality":"Somajiguda",
						"city": "Hyderabad",
						"state": "Andhra Pradesh",
						"postal": "500082",
						"latitude": "17.252254",
						"longitude": "78.274445"
					},
					"hall_rating":"3",
					"hall_website": "http://www.cityhospital.org",
					"hall_phone": "040 6666 0255",
					"hall_type": {
						"corporate": "false",
						"wedding": "true",
						"party": "false",
						"banquet":"false"
					},
					"hall_features":["icons-parking;Parking","icons-coffee;Cafe","icons-bar;Bar","icons-book;Reading hall","icons-swimming;Swimming pool","icons-signal;Wi-fi","icons-gym;Gym"]
				},
				{
					"hall_id": "4",
					"hall_name": "Pizza Hut 4",
					"hall_address": {
						"country": "India",
						"address_1": "1-98/6/51, Hitech City Road",
						"address_2": "Shristi Towers, Arunodaya Colony",
						"locality":"Madhapur",
						"city": "Hyderabad",
						"state": "Andhra Pradesh",
						"postal": "500081",
						"latitude": "17.264380",
						"longitude": "78.230987"
					},
					"hall_rating":"3",
					"hall_website": "http://www.cityhospital.org",
					"hall_phone": "040 6666 0255",
					"hall_type": {
						"corporate": "false",
						"wedding": "false",
						"party": "true",
						"banquet":"false"
					},
					"hall_features":["icons-parking;Parking","icons-coffee;Cafe","icons-bar;Bar","icons-book;Reading hall","icons-swimming;Swimming pool","icons-signal;Wi-fi","icons-gym;Gym"]
				},
				{
					"hall_id": "5",
					"hall_name": "Pizza Hut 5",
					"hall_address": {
						"country": "India",
						"address_1": "Huda Techno Enclave",
						"address_2": "Hitech City Main Road",
						"locality":"Hitech City",
						"city": "Hyderabad",
						"state": "Andhra Pradesh",
						"postal": "500081",
						"latitude": "17.264500",
						"longitude": "78.223947"
					},
					"hall_rating":"3",
					"hall_website": "http://www.cityhospital.org",
					"hall_phone": "040 6666 0255",
					"hall_type": {
						"corporate": "false",
						"wedding": "false",
						"party": "false",
						"banquet":"true"
					},
					"hall_features":["icons-parking;Parking","icons-coffee;Cafe","icons-bar;Bar","icons-book;Reading hall","icons-swimming;Swimming pool","icons-signal;Wi-fi","icons-gym;Gym"]
				},
				{
					"hall_id": "6",
					"hall_name": "Pizza Hut 6",
					"hall_address": {
						"country": "India",
						"address_1": "Inorbit Mall, Durgamma Cheruvu Rd",
						"address_2": "Vittal Rao Nagar, Hitech City",
						"locality":"Hitech City",
						"city": "Hyderabad",
						"state": "Andhra Pradesh",
						"postal": "500081",
						"latitude": "17.260441",
						"longitude": "78.231327"
					},
					"hall_rating":"1",
					"hall_website": "http://www.cityhospital.org",
					"hall_phone": "040 6666 0255",
					"hall_type": {
						"corporate": "true",
						"wedding": "false",
						"party": "true",
						"banquet":"true"
					},
					"hall_features":["icons-parking;Parking","icons-coffee;Cafe","icons-bar;Bar","icons-book;Reading hall","icons-swimming;Swimming pool","icons-signal;Wi-fi","icons-gym;Gym"]
				}
			]
		}
	};
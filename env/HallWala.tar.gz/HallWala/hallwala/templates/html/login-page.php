<?php
	$title = 'Login page';
	require('helper/headtag.php');
?>
<link href="../css/components/map-specific.css" rel="stylesheet">
<div id="main-wrapper">
	<div id="content-wrapper">
		<div id="main-container">
        	<?php
				require('helper/header.php');
			?>
            <?php
				require('helper/navigation.php');
			?>
            <?php
				require('components/plain-banner.php');
			?>
            <div class="general-form-container">
                <h2>Login</h2>
                <form id="add_hall_price_package">
                    <table class="form-table">
                    <tr>
                    	<th>
                            Username
                        </th>
                    </tr>
                    <tr>
                        <td>
                            <div class="hw-form-input">
                                <input type="text" />
                            </div>
                        </td>
                        
                    </tr>
                    <tr>
                    	<th>
                            Password
                        </th>
                    </tr>
                    <tr>
                        <td>
                            <div class="hw-form-input">
                                <input type="password" />
                            </div>
                        </td>
                        
                    </tr>
                    <tr>
                    	<td><a href="#">Forgot password?</a>
                    </tr>
                    <tr>
                        <td>
                           <button type="submit" class="cta-link primary">Login<span class="cta-arrow icons-right-open"></span></button>
                        </td>
                    </tr>
                </table>
                </form>
            </div>
        </div>     
	</div>
</div>
<?php
	require('helper/footer.php');
?>
<?php
	require('helper/scripthelper.php');
?>
<!-- <script src="http://maps.googleapis.com/maps/api/js?sensor=false"></script> -->
<script src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="../js/infobox.js"></script>
<script type="text/javascript" src="../mapjson.js"></script>
<script type="text/javascript" src="../js/map-specific.js"></script>
</body>
</html>

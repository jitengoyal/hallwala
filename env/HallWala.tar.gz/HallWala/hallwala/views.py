from pyramid.response import Response
from pyramid.view import view_config,forbidden_view_config
from pyramid.security import remember,authenticated_userid, forget, Authenticated
from pyramid.httpexceptions import HTTPFound

from models import DBSession

from sqlalchemy import and_
import hashlib

#@view_config(route_name='home',renderer='index.mako', permission='__no_permission_required__')
#def homeView(request):
#    return {}



#@view_config(route_name='home', renderer='html/homepage.mako', permission='__no_permission_required__')
@view_config(route_name='home',effective_principals=[Authenticated], renderer='html/homepage.mako')
def dashboard(request):
    title = "HomePage"
    return dict(title=title)

#@view_config(route_name='loginPage',effective_principals=[Authenticated], renderer='html/login_page.mako')
@view_config(route_name='loginPage', renderer='html/login_page.mako',permission='__no_permission_required__')
def loginPage(request):
    title = "Login Page"
    return dict(title = title)

@view_config(route_name='changePassword',effective_principals=[Authenticated], renderer='html/change_password.mako')
def changePassword(request):
    title = "Change Password"
    return dict(title = title)

@view_config(route_name='addAHall',effective_principals=[Authenticated], renderer='html/add_a_hall.mako')
def addAHall(request):
    title = "Add a Hall"
    return dict(title = title)

@view_config(route_name='venue',effective_principals=[Authenticated], renderer='venue.mako')
def venue(request):
    return {}

@view_config(route_name='venueReview',effective_principals=[Authenticated], renderer='venue_review.mako')   
def venueReview(request):
    venueId = request.matchdict['venue_id']
    return dict(venueId=venueId)

@view_config(route_name='venueFeedback',effective_principals=[Authenticated], renderer='venue_feedback.mako')   
def venueFeedback(request):
    venueId = request.matchdict['venue_id']
    return dict(venueId=venueId)

@view_config(route_name='venueFacilities',effective_principals=[Authenticated], renderer='venue_facilities.mako')   
def venueFacilities(request):
    venueId = request.matchdict['venue_id']
    return dict(venueId=venueId)


@view_config(route_name='agent',effective_principals=[Authenticated], renderer='html/agent_registration.mako')
def agent(request):
    title = "Agent Registration"
    return dict(title = title,page={})

#@view_config(route_name='agentProfile', effective_principals=[Authenticated],renderer='html/agent_profile.mako')
@view_config(route_name='agentProfile',renderer='html/agent_profile.mako', permission='__no_permission_required__')
def agentProfile(request):
    title = "My Profile"
    return dict(title = title)


@view_config(route_name='customer',effective_principals=[Authenticated], renderer='customer.mako')
def customer(request):
    return {}

@view_config(route_name='howItWorks',renderer='how_it_works.mako', permission='__no_permission_required__')
def howItWorks(request):
    return {}



@view_config(route_name='contact',renderer='contact.mako', permission='__no_permission_required__')
def contact(request):
    return {}



@view_config(route_name='aboutUs',renderer='about_us.mako', permission='__no_permission_required__')
def aboutUs(request):
    return {}



@view_config(route_name='termsAndConditions',renderer='html/terms.mako', permission='__no_permission_required__')
def termsAndConditions(request):
    title = "Terms and Conditions"
    return dict(title = title)



@view_config(route_name='vision',renderer='vision.mako', permission='__no_permission_required__')
def vision(request):
    return {}



@view_config(route_name='team',renderer='team.mako', permission='__no_permission_required__')
def team(request):
    return {}




@forbidden_view_config()
def forbidden(request):
    return Response('Not Allowed')



@view_config(context='pyramid.exceptions.NotFound', renderer='json', permission='__no_permission_required__')
def notFound_view(request):
    notFound404 = '404 Not Found'
    return {'error' : notFound404}



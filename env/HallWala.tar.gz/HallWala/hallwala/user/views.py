from pyramid.response import Response
from pyramid.view import view_config, forbidden_view_config
from pyramid.security import remember,authenticated_userid, forget, Authenticated

from pyramid.httpexceptions import HTTPFound

import urllib2,json

from .models import DBSession
from .models import User
from .models import Vendor
from .models import Customer
from .models import Contact
from ..util import row2dict

from login_provider import loginTwitter,loginGoogle,loginFacebook


@view_config(
    context='velruse.AuthenticationComplete',
    renderer='blank.mako',
    permission='__no_permission_required__'
)
def login_complete_view(request):
    
    context = request.context
    result = {
        'provider_type': context.provider_type,
        'provider_name': context.provider_name,
        'profile': context.profile,
        'credentials': context.credentials,
    }

    provider_name = result['provider_name']

    if provider_name == 'twitter':
        dbFoundUser = loginTwitter(result)
    elif provider_name == 'google':
        dbFoundUser = loginGoogle(result)
    elif provider_name == 'facebook':
        dbFoundUser = loginFacebook(result)

    request.session['user'] = dbFoundUser.getJSON()
    headers = remember(request,dbFoundUser.id) 

    return HTTPFound(location = request.route_url('home'), headers = headers)

@view_config(route_name='logout')
def logout(request):
    
    currentUser = int(authenticated_userid(request))
    headers = forget(request)
    
    request.session.invalidate()
    return HTTPFound(location = request.route_url('home'), headers = headers)


@view_config(
	route_name='agentRegister',
	renderer='json',
	request_method='POST'
)
def agentRegister(request):
	firstName = request.POST['first_name']
	lastName = request.POST['last_name']
	email = request.POST['email']
	password = request.POST['password']
	typeContact = request.POST['type']
	infoContact = request.POST['info']
	panCard = request.POST['pancard']

	newUser = User(firstName,firstName + " " + lastName,lastName,email,None,None,None,None,None,password,None)
	DBSession.add(newUser)
	DBSession.flush()

	newVendor = Vendor(newUser.id,panCard)
	DBSession.add(newVendor)
	DBSession.flush()

	newContact = Contact(newUser.id,typeContact,infoContact)
	DBSession.add(newContact)
	DBSession.flush()

	vendor = newVendor.getJSON();
	return json.dumps({'status' : 'OK'})
#	return {'vendor' : vendor}


@view_config(
	route_name='emailValidation',
	renderer='json',
	request_method='POST'
)
def emailValidation(request):
	email = request.POST['email']
	user = DBSession.query(User).filter(User.email == email).first()
	if user == None:
		return json.dumps({'status' : 'OK'})
		
	return json.dumps({'status' : 'NOT OK'})

@view_config(
	    route_name='agentDetails',
	    renderer='json',
	    request_method='POST'
)   
def agentDetails(request):
	agentId = request.session['vendorId']
	agentQuery = DBSession.query(Vendor.user_id).filter(Vendor.id == agentId).scalar()

	userQuery = DBSession.query(User.given_name,User.family_name,User.email).filter(User.id == agentQuery).all()

	firstName = userQuery[0].given_name
	lastName = userQuery[0].family_name
	email = userQuery[0].email
        contactQuery = DBSession.query(Contact.info).filter(Contact.user_id == agentQuery).scalar()

       	agentDetail = {}
        agentDetail['first_name'] = firstName
	agentDetail['last_name'] = lastName
	agentDetail['email'] = email
	agentDetail['info'] = contactQuery
	return json.dumps(agentDetail)


@view_config(
	    route_name='updateDetails',
	    renderer='json',
	    request_method='POST'
)
def updateDetails(request):
	firstName = request.POST['first_name']
	lastName = request.POST['last_name']
	email = request.POST['email']
	contactInfo = request.POST['contact_info']
	formattedName = firstName + " " + lastName

	agentId = request.session['vendorId']
	agentQuery = DBSession.query(Vendor.user_id).filter(Vendor.id == agentId).scalar()

        userQuery = DBSession.query(User).filter(User.id== agentQuery).update({"given_name" : firstName,"family_name" : lastName,"email" : email,"formatted" : formattedName})
        contactQuery = DBSession.query(Contact).filter(Contact.user_id== agentQuery).update({"info" : contactInfo})
	return json.dumps({'status' : 'OK'})

	
@view_config(
	route_name='customerRegister',
	renderer='json',
	request_method='POST'
)
def customerRegister(request):
	firstName = request.POST['first_name']
	lastName = request.POST['last_name']
	email = request.POST['email']
	password = request.POST['password']
	typeContact = request.POST['type']
	infoContact = request.POST['info']

	newUser = User(firstName,firstName + " " + lastName,lastName,email,None,None,None,None,None,password,None)
	DBSession.add(newUser)
	DBSession.flush()

	newCustomer = Customer(newUser.id)
	DBSession.add(newCustomer)
	DBSession.flush()

	newContact = Contact(newUser.id,typeContact,infoContact)
	DBSession.add(newContact)
	DBSession.flush()

	customer = newCustomer.getJSON();
	return {'customer' : customer}



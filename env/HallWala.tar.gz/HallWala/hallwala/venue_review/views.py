from pyramid.httpexceptions import HTTPFound
from pyramid.view import view_config
from pyramid.response import Response
from pyramid.security import authenticated_userid

from .models import DBSession
from .models import User
from .models import Vendor
from .models import Venue
from .models import VenueReview
from .models import VenueFeedback


@view_config(
	route_name='venueReviewAdd',
	renderer='json',
	request_method='POST'
	    )   
def venueReviewAdd(request):

	customerReview = request.POST['review']
	venueId = request.POST['venueId']

	newVenueReview = VenueReview(customerReview,venueId,request.session['user']['id'])
	DBSession.add(newVenueReview)
	DBSession.flush()

 	venueReview = newVenueReview.getJSON()
	return {'venue_review' : venueReview}


@view_config(
	route_name='venueFeedbackAdd',
	renderer='json',
	request_method='POST'
	    )   
def venueFeedbackAdd(request):

	customerFeedback = request.POST['feedback']
	venueId = request.POST['venueId']
	print request.session['user']['id']

	newVenueFeedback = VenueFeedback(customerFeedback,venueId,request.session['user']['id'])
	DBSession.add(newVenueFeedback)
	DBSession.flush()

 	venueFeedback = newVenueFeedback.getJSON()
	return {'venue_feedback' : venueFeedback}

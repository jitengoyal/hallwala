import json
import glob
import PIL
from PIL import Image
import os
import uuid
from pyramid.response import Response
from pyramid.view import view_config, forbidden_view_config
from pyramid.security import remember,authenticated_userid, forget, Authenticated

from pyramid.httpexceptions import HTTPFound
import urllib2,json

from .models import DBSession
from .models import User
from .models import Vendor
from .models import Contact
from .models import Accomodation
from .models import Venue
from .models import VenueLocation
from .models import VenueImage
from .models import VenueContact
from .models import VenueEvent
from .models import VenueFacilities


@view_config(
	route_name='homePage',
	renderer='json',
	request_method='POST'
	    )
def homePage(request):
	email = request.POST['user_name']
	password = request.POST['pass_word']
	userQuery = DBSession.query(User.id).filter(User.email == email). \
		                                     filter(User.password == password).scalar()
	vendorQuery = DBSession.query(Vendor.id).filter(userQuery == Vendor.user_id).scalar()
	print "##########################################"
	print email
	print password
	print "##########################################"
	if userQuery == None:
		return json.dumps({'status' : 'error'})
	else:
		request.session['vendorId'] = vendorQuery
		return json.dumps({'vendor_id' : request.session['vendorId']})


@view_config(
	route_name='venueAdd',
	renderer='json',
	request_method='POST'
	    )
def venueAdd(request):
	name = request.POST['name']
	description =  request.POST['description']
	registrationNumber = request.POST['registration_number']
	maximumAccomodation = request.POST['maximum_accomodation']
	minimumAccomodation = request.POST['minimum_accomodation']
	latitude = request.POST['latitude']
	longitude = request.POST['longitude']
	state = request.POST['state']
	city = request.POST['city']
	locality = request.POST['locality']
	address = request.POST['address']
	typeVenueContact = request.POST['type']
	infoVenueContact = request.POST['info']
	caption = request.POST['caption']


	image = request.POST.getall('image')
	for i in image:
		fileExtension = (str(i.filename)).split(".")[-1]
		fileExtension.lower()
		if fileExtension == 'jpg' or fileExtension == 'png' or fileExtension == 'jpeg':
			print ''
		else:
			return {'error' : 'Uploaded file is not an image'}


	newAccomodation = Accomodation(minimumAccomodation,maximumAccomodation)
	DBSession.add(newAccomodation)
	DBSession.flush()

	newVenue = Venue(name,description,registrationNumber,newAccomodation.id,request.session['vendorId'])
	DBSession.add(newVenue)
	DBSession.flush()


	for i in image:	
		imageId = uuid.uuid1()
		imageUrl = str(imageId)
		f = open('/home/jiten/env/HallWala/hallwala/images/%s.jpeg' % (imageUrl), 'wb')
		buf = f.write(i.file.read())
		f.close()
		path = "/home/jiten/env/HallWala/hallwala/"
		pathImage = path + "images/" + imageUrl + ".jpeg"
		im = Image.open(pathImage)
		im.thumbnail((128, 128), Image.ANTIALIAS)
		pathThumbnail = path + "thumbnail/" + imageUrl + ".jpeg"
		im.save(pathThumbnail, "JPEG")
		newVenueImage = VenueImage(imageUrl,imageUrl,caption,newVenue.id)
		DBSession.add(newVenueImage)
		DBSession.flush()
	

	newVenueLocation = VenueLocation(latitude,longitude,state,city,locality,address,newVenue.id)
	DBSession.add(newVenueLocation)
	DBSession.flush()

	newVenueContact = VenueContact(typeVenueContact,infoVenueContact,newVenue.id)
	DBSession.add(newVenueContact)
	DBSession.flush()

	venue = newVenue.getJSON()
	return {'venue' : venue}


@view_config(
	route_name='venueFacilitiesAdd',
	renderer='json',
	request_method='POST'
	    )   
def venueFacilitiesAdd(request):

	area = request.POST['area']
	numHalls = request.POST['num_halls']
	numGuestRooms = request.POST['num_guest_rooms']
	guestRoomsPrice = request.POST['guest_rooms_price']
	garden = 0
	cateringInBudget = 0
	decorationInBudget = 0
	bridalMakeup = 0
	guestMakeup = 0
	danceMusicDj = 0

	if 'garden' in request.POST.keys():
		garden = request.POST['garden']
	catering = request.POST['catering']
	if 'catering_in_budget' in request.POST.keys():
		cateringInBudget = request.POST['catering_in_budget']
	decoration = request.POST['decoration']
	if 'decoration_in_budget' in request.POST.keys():
		decorationInBudget = request.POST['decoration_in_budget']
	if 'bridal_makeup' in request.POST.keys():
		bridalMakeup = request.POST['bridal_makeup']
	if 'guest_makeup' in request.POST.keys():
		guestMakeup = request.POST['guest_makeup']
	if 'dance_music_dj' in request.POST.keys():
		danceMusicDj = request.POST['dance_music_dj']
	transport = request.POST['transport']
	venueId = request.POST['venue_id']


	newVenueFacilities = VenueFacilities(area, numHalls, numGuestRooms, guestRoomsPrice, garden, catering, cateringInBudget, decoration, decorationInBudget, bridalMakeup, guestMakeup, danceMusicDj, transport, venueId)
	DBSession.add(newVenueFacilities)
	DBSession.flush()

	venueFacilities = newVenueFacilities.getJSON()
	return {'venue_facilities' : venueFacilities}


@view_config(
	route_name='venueGet',
	renderer='json',
	request_method='GET'
	    )
def venueGet(request):

	venueId = int(request.matchdict['venue_id'])

	venueQuery = DBSession.query(Venue).filter(Venue.id == venueId).first()
	venue = venueQuery.getJSON()

	return {'venue' : venue}


@view_config(
	route_name='venueGetAll',
	renderer='json',
	request_method='GET'
	    )
def venueGetAll(request):

	venueQuery = DBSession.query(Venue)

	venues = []
	for venue in venueQuery.all():
		venues.append(venue.getJSON())

	return {'venues' : venues}

